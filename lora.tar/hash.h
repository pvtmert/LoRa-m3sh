
#ifndef _LORA_STATIC_HASH_H_
#define _LORA_STATIC_HASH_H_

#define H1(s,i,x)   (x*65599u+(uint8_t)s[(i)<strlen(s)?strlen(s)-1-(i):strlen(s)])
#define H4(s,i,x)   H1(s,i,H1(s,i+1,H1(s,i+2,H1(s,i+3,x))))
#define H16(s,i,x)  H4(s,i,H4(s,i+4,H4(s,i+8,H4(s,i+12,x))))
#define H64(s,i,x)  H16(s,i,H16(s,i+16,H16(s,i+32,H16(s,i+48,x))))
#define H256(s,i,x) H64(s,i,H64(s,i+64,H64(s,i+128,H64(s,i+192,x))))
//#define HASH(s)    ((uint32_t)(H256(s,0,0)^(H256(s,0,0)>>16)))
#define HASH(s)     H16(s,0,H16(s,16,H16(s,32,H16(s,48,0))))

inline static
uint64_t hash(const char *str) {
	unsigned length = strlen(str);
	uint64_t result = 0;
	for(int i=0; i<length; i++) {
		int tmp = 0x7F ^ ((str[i] - 32) % 94);
		result = result | (tmp << ((i * 7) % 24));
		continue;
	}
	return result;
}

#endif
